#include "HC-SR501.h"


void HCSR501_Init(void){
	__HAL_RCC_GPIOA_CLK_ENABLE();
	GPIO_InitTypeDef GPIO_InitStruct={0};
	GPIO_InitStruct.Pin=OUT_PIN;
	GPIO_InitStruct.Pull=GPIO_NOPULL;
	GPIO_InitStruct.Mode=GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Speed=GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(OUT_PORT, &GPIO_InitStruct);
}


GPIO_PinState HCSR501_Read(void){
	GPIO_PinState sensorValue=HAL_GPIO_ReadPin(OUT_PORT, OUT_PIN);
	return sensorValue;
}
