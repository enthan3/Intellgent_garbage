#include "Wio-E5.h"
UART_HandleTypeDef huart2;
void WioE5_UART_Init(void){
	__HAL_RCC_USART2_CLK_ENABLE();
	  huart2.Instance = USART2;
	  huart2.Init.BaudRate = 9600;
	  huart2.Init.WordLength = UART_WORDLENGTH_8B;
	  huart2.Init.StopBits = UART_STOPBITS_1;
	  huart2.Init.Parity = UART_PARITY_NONE;
	  huart2.Init.Mode = UART_MODE_TX_RX;
	  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
	  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
	  huart2.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
	  huart2.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
	  if (HAL_UART_Init(&huart2) != HAL_OK)
	  {
	    Error_Handler();
	  }
}

void WioE5_Init(void){

	__HAL_RCC_GPIOD_CLK_ENABLE();
	GPIO_InitTypeDef GPIO_InitStruct ={0};
	GPIO_InitStruct.Pin=TX_PIN;
	GPIO_InitStruct.Mode=GPIO_MODE_AF_PP;
	GPIO_InitStruct.Pull=GPIO_NOPULL;
	GPIO_InitStruct.Speed=GPIO_SPEED_FREQ_LOW;
	GPIO_InitStruct.Alternate=GPIO_AF7_USART2;
	HAL_GPIO_Init(TX_PORT, &GPIO_InitStruct);

	GPIO_InitStruct.Pin=RX_PIN;
	GPIO_InitStruct.Mode=GPIO_MODE_AF_PP;
	GPIO_InitStruct.Pull=GPIO_NOPULL;
	GPIO_InitStruct.Speed=GPIO_SPEED_FREQ_LOW;
	GPIO_InitStruct.Alternate = GPIO_AF7_USART2;
	HAL_GPIO_Init(RX_PORT, &GPIO_InitStruct);
	WioE5_UART_Init();
	HAL_Delay(100);
	send_command(&huart2, "AT\r\n");
	HAL_Delay(100);
	send_command(&huart2,"AT+MODE=TEST\r\n");
	HAL_Delay(100);
	send_command(&huart2, "AT+TEST=RFCFG,868,SF7,125,8,8,14,OFF,OFF,OFF\r\n");
	HAL_Delay(100);
	send_command(&huart2, "AT+TEST=RXLRPKT\r\n");
	HAL_Delay(100);
}

void WioE5_Send_Data(char* data){
	uint32_t len=strlen(data);
	char cmd[30+len*2+1];
	char formatted_str[len*2+1];
	for (int32_t i=0; i<len;i++){
		sprintf(&formatted_str[i*2],"%02X",(unsigned char)data[i]);
	}
	formatted_str[len*2]='\0';
	sprintf(cmd, "AT+TEST=TXLRPKT,\"%s\"\r\n",formatted_str);
	send_command(&huart2, cmd);
}


void send_command(UART_HandleTypeDef *huart, char *cmd) {
    HAL_StatusTypeDef status=HAL_UART_Transmit(huart, (uint8_t *)cmd, strlen(cmd), 500);
    if (status==HAL_OK){
    HAL_GPIO_TogglePin(GPIOB, GPIO_PIN_7);
    }
}

