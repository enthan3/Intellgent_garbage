#include "VOC_Sensor.h"

uint32_t Measured_Voltage;
uint32_t PPM;
ADC_HandleTypeDef hadc3;
const uint32_t VREF_MV = 3300;

void VOC_ADC_Init(void){
	__HAL_RCC_ADC3_CLK_ENABLE();
	hadc3.Instance=ADC3;
	hadc3.Init.ClockPrescaler=ADC_CLOCK_SYNC_PCLK_DIV4;
	hadc3.Init.Resolution=ADC_RESOLUTION_12B;
	hadc3.Init.DataAlign=ADC_DATAALIGN_RIGHT;
	hadc3.Init.ScanConvMode=DISABLE;
	hadc3.Init.EOCSelection=ADC_EOC_SINGLE_CONV;
	hadc3.Init.ContinuousConvMode=DISABLE;
	hadc3.Init.DMAContinuousRequests=DISABLE;
	hadc3.Init.DiscontinuousConvMode=DISABLE;
	if (HAL_ADC_Init(&hadc3)!=HAL_OK){
		Error_Handler();
	}
	ADC_ChannelConfTypeDef sConfig={0};
	sConfig.Channel=ADC_CHANNEL_9;
	sConfig.Rank=1;
	sConfig.SamplingTime=ADC_SAMPLETIME_144CYCLES;
	if (HAL_ADC_ConfigChannel(&hadc3, &sConfig)!=HAL_OK){
		Error_Handler();
	}
}

void VOC_Init(void){
	__HAL_RCC_GPIOF_CLK_ENABLE();
	GPIO_InitTypeDef GPIO_InitStruct ={0};
	GPIO_InitStruct.Pin=VOC_PIN;
	GPIO_InitStruct.Mode=GPIO_MODE_ANALOG;
	GPIO_InitStruct.Pull=GPIO_NOPULL;
	HAL_GPIO_Init(VOC_PORT, &GPIO_InitStruct);
	VOC_ADC_Init();
}


void VOC_Read_Value(void){
	if (HAL_ADC_Start(&hadc3)!=HAL_OK){
		Error_Handler();
	}
	if (HAL_ADC_PollForConversion(&hadc3,HAL_MAX_DELAY)!=HAL_OK){
		Error_Handler();
	}
	uint32_t ADC_Value=HAL_ADC_GetValue(&hadc3);
	uint32_t maxADCValue=4095;
	Measured_Voltage=ADC_Value*VREF_MV/maxADCValue;
	PPM=Measured_Voltage*500/VREF_MV;
	HAL_ADC_Stop(&hadc3);
}


