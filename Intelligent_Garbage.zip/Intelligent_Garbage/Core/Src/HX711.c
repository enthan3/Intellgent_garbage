#include "HX711.h"
// Since my Module is broken this has been not fully tested. if you have any questions, feel free to email me or change this accordingly to

int32_t offset=0;

//Change this accordingly by using a known weight. e.g. 5kg, and compare with get weight function
int32_t scale_factor=1000;

void HX711_Init(void){
	__HAL_RCC_GPIOG_CLK_ENABLE();
	GPIO_InitTypeDef GPIO_InitStruct={0};
	GPIO_InitStruct.Mode=GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pin=HX711_CLK_PIN;
	GPIO_InitStruct.Pull=GPIO_NOPULL;
	GPIO_InitStruct.Speed=GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(HX711_CLK_PORT, &GPIO_InitStruct);

	GPIO_InitStruct.Mode=GPIO_MODE_INPUT;
	GPIO_InitStruct.Pin=HX711_DAT_PIN;

	HAL_GPIO_Init(HX711_DAT_PORT, &GPIO_InitStruct);
	HAL_GPIO_WritePin(HX711_CLK_PORT, HX711_CLK_PIN, GPIO_PIN_RESET);
}

int32_t HX711_Read(void) {
    int32_t count = 0;

    while (HAL_GPIO_ReadPin(HX711_DAT_PORT, HX711_DAT_PIN));

    for (int i = 0; i < 24; i++) {
        HAL_GPIO_WritePin(HX711_CLK_PORT, HX711_CLK_PIN, GPIO_PIN_SET);
        count = count << 1;
        HAL_GPIO_WritePin(HX711_CLK_PORT, HX711_CLK_PIN, GPIO_PIN_RESET);

        if (HAL_GPIO_ReadPin(HX711_DAT_PORT, HX711_DAT_PIN)) {
            count++;
        }
    }


    HAL_GPIO_WritePin(HX711_CLK_PORT, HX711_CLK_PIN, GPIO_PIN_SET);
    count ^= 0x800000;
    if (count & 0x800000) {
        count |= 0xFF000000;
    }
    HAL_GPIO_WritePin(HX711_CLK_PORT, HX711_CLK_PIN, GPIO_PIN_RESET);

     return count;
}

//This function is use to calculate initial offset caused by strain initial condition, in final calculation to minus this value to get better accuracy
void HX711_Tare(void) {
    offset = HX711_Read();
}

int32_t HX711_GetWeight(void) {
    int32_t raw_value = HX711_Read();
    int32_t net_value = raw_value - offset;

    int32_t weight_in_grams = net_value / scale_factor;

    return weight_in_grams;
}
