#include "../../STM32F7xx_HAL_Driver/Inc/stm32f7xx_hal.h"
#include <string.h>

#define OLED_WIDTH 128
#define OLED_HEIGHT 64
#define ROWS_PER_PAGE 8
#define OLED_PAGE_NUMBER OLED_HEIGHT/ROWS_PER_PAGE
#define BIT_PER_BYTE 8
#define OLED_TOTAL_BITS OLED_HEIGHT*OLED_WIDTH
#define OLED_BUFFER_SIZE_PER_PAGE (OLED_TOTAL_BITS/(OLED_PAGE_NUMBER*BIT_PER_BYTE))
#define SSD1315_I2C_ADDR 0x3C
//8x8 so that it will fit perfectly under one page
extern const uint8_t font8x8_basic[][8];
extern uint8_t OLED_GRAM[OLED_PAGE_NUMBER][OLED_BUFFER_SIZE_PER_PAGE];
void OLED_init(I2C_HandleTypeDef* i2c);
void OLED_update(I2C_HandleTypeDef* i2c);
void SSD1315_WriteCommand(uint8_t command,I2C_HandleTypeDef* i2c);
void OLED_write_char(char c,uint8_t page_number,uint8_t index);
void OLED_write_line(char* text,uint8_t page_number);
