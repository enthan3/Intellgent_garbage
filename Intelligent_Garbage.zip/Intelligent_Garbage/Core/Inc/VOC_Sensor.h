#include "../../STM32F7xx_HAL_Driver/Inc/stm32f7xx_hal.h"
#include "main.h"

#define VOC_PORT GPIOF
#define VOC_PIN GPIO_PIN_3

void VOC_ADC_Init(void);
void VOC_Init(void);
void VOC_Read_Value(void);

