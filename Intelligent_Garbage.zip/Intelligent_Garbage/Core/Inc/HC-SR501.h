#include "../../Drivers/STM32F7xx_HAL_Driver/Inc/stm32f7xx_hal.h"
#include "main.h"

#define OUT_PORT GPIOA
#define OUT_PIN GPIO_PIN_0

void HCSR501_Init(void);
GPIO_PinState HCSR501_Read(void);
