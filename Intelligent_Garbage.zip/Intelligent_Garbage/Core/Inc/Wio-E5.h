#include "../../STM32F7xx_HAL_Driver/Inc/stm32f7xx_hal.h"
#include "main.h"
#include <string.h>
#include <stdio.h>

#define RX_PIN GPIO_PIN_6
#define RX_PORT GPIOD

#define TX_PIN GPIO_PIN_5
#define TX_PORT GPIOD


extern UART_HandleTypeDef huart3;
void WioE5_UART_Init(void);
void WioE5_Init(void);
void send_command(UART_HandleTypeDef *huart, char *cmd);
void WioE5_Send_Data(char* data);
