#include "../../STM32F7xx_HAL_Driver/Inc/stm32f7xx_hal.h"
#include "main.h"

#define HX711_CLK_PIN GPIO_PIN_2
#define HX711_CLK_PORT GPIOG

#define HX711_DAT_PIN GPIO_PIN_3
#define HX711_DAT_PORT GPIOG

void HX711_Init(void);
int32_t HX711_Read(void);
void HX711_Tare(void);
int32_t HX711_GetWeight(void);
